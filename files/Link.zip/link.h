#ifndef LINK_H_INCLUDED
#define LINK_H_INCLUDED
#include<iostream>
struct link
{
    int d;
    link* next;
};
class linklist
{
private:
    link* FIRST;
public:
    linklist()
    {
        FIRST = NULL;
    }
    void Insert(int n);
    void Delete(int n);
    bool Search(int n);
    void display();
};

struct d_link
{
    int num;
    d_link* prev;
    d_link* next;
};
class d_linklist
{
private:
    d_link* Front;
    d_link* End;
public:
    d_linklist()
    {
        Front = NULL;
        End = NULL;
    }
    void Insert(int);
    void display_front();
    void display_end();
    void delete_front();
    void delete_end();
    bool isempty();
};

#endif // LINK_H_INCLUDED
