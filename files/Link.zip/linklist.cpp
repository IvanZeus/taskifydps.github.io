#include"link.h"
#include<iostream>
using namespace std;

void linklist::Insert(int n)
{
    link* newlink;
    newlink = new link;
    newlink->d = n;
    newlink->next = FIRST;
    FIRST = newlink;
}

bool linklist::Search(int n)
{
    link* t;
    t = FIRST;
    while(t!=NULL&&t->d!=n)
        t = t->next;
    if(t->d==n)
        return true;
    else
        return false;
}

void linklist::display()
{
    link* t;
    t = FIRST;
    while(t!=NULL)
    {
        cout<<t->d;
        t = t->next;
    }

}
void linklist::Delete(int n)
{
   link* t;
    t = FIRST;
    while(t->next!=NULL&&t->next->d!=n)
        t = t->next;
    if(t->next->d==n){
        link* temp;
        temp = t->next->next;
        delete t->next;
        t->next = temp;
    }

}


void d_linklist::Insert(int n)
{
    d_link* t;
    t = new d_link;
    t->num = n;
    if(Front == NULL)
    {
        t->next = t->prev = NULL;
        End = t;
        Front = t;
    }
    else
    {
        End->next = t;
        t->prev = End;
        t->next = NULL;
        End = t;
    }
}
void d_linklist:: display_front()
{
    d_link* t;
    t = Front;
    cout<<endl;
    while(t!=NULL)
    {
        cout<<t->num<<endl;
        t = t->next;
    }
}
void d_linklist:: display_end()
{
    d_link* t;
    t = End;
    cout<<endl;
    while(t!=NULL)
    {
        cout<<t->num<<endl;
        t = t->prev;
    }
}
void d_linklist::delete_front()
{
    d_link* t;
    t = Front;
    Front = Front->next;
    delete t;
    if(Front!=NULL)
        Front->prev = NULL;
    else
        End = NULL;
}
void d_linklist::delete_end()
{
    d_link* t;
    t = End;
    End = End->prev;
    delete t;
    if(End!=NULL)
        End->next = NULL;
    else
        Front = NULL;
}
bool d_linklist:: isempty()
{
    if(Front==NULL||End==NULL)
        return true ;
    else
        return false;
}
