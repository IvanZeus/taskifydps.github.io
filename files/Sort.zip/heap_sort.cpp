#include"sort.h"
#include<iostream>

void Swap(int& a, int& b)
{
    int t;
    t = a;
    a = b;
    b = t;
}

void max_heapify(int* arr, int n, int i)
{
    int t;
    int Max = i;

    int l = 2*i+1;
    int r = 2*i+2;

    if(arr[l]>arr[Max]&&l<n)
        Max = l;

    if(arr[r]>arr[Max]&&r<n)
        Max = r;

    if(Max!=i)
    {
        Swap(arr[i],arr[Max]);

        max_heapify(arr,n,Max);
    }
}

void heap_sort(int* arr, int n)
{
    int i;
    for(i=(n/2-1);i>=0;i--)
        max_heapify(arr, n ,i);
    for(i=n-1;i>=0;i--)
    {
        Swap(arr[0],arr[i]);
        max_heapify(arr,i,0);
    }
}
