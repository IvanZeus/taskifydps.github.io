#include<iostream>
using namespace std;

void Swap(int& a, int& b)
{
    int t;
    t=a;
    a=b;
    b=t;
}

int Partition(int* arr, int s, int e)
{
    int t = e;
    int pivot = arr[e];
    int i = s - 1;
    for (int j=s;j<e-1,j!=t;j++)
    {
        if(arr[j]<=pivot)
        {
            i++;
            Swap(arr[i],arr[j]);
        }
    }
    Swap(arr[i+1],arr[t]);
    return i+1;
}
void quick_sort(int* arr, int s, int e)
{
    if(s<e)
    {
        int pi;
        pi = Partition(arr,s,e);

        quick_sort(arr,s,pi-1);
        quick_sort(arr,pi+1,e);
    }
}
