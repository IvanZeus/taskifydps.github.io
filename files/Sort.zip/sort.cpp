#include<iostream>
#include"sort.h"

void Swap(int& a,int& b)
{
    int t;
    t = a;
    a = b;
    b = t;
}

void selection_sort(int* arr,int n)
{
    int i,j;
    for(i=0;i<n-1;i++)
        for(j=i+1;j<n;j++)
            if(arr[i]>arr[j])
                Swap(arr[i],arr[j]);
}
void bubble_sort(int* arr, int n)
{
    int i,j;
    for(i=1;i<n;i++)
        for(j=0;j<n-i;j++)
            if(arr[j]>arr[j+1])
                Swap(arr[j],arr[j+1]);
}
void insert_sort(int* arr, int n)
{
    int t,i,j;
    for(i=1;i<n;i++)
    {
        t = arr[i];
        j = i-1;
        while(arr[j]>t && j>=0){
            arr[j+1]=arr[j];
            j--;
        }
        arr[j+1]=t;
    }
}
