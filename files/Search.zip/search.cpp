#include<iostream>
#include"search.h"

int linear_search(int* arr, int n, int k)
{
    int i;
    for(i=0;i<n;i++)
    {
        if(arr[i]==k)
            return i;
    }
    if(i>=n)
        return -1;
}

int binary_search(int* arr, int n, int k)
{
    int start = 0;
    int End = n;
    int mid = (start+End)/2;
    while(arr[mid]!=k&&start<=End)
    {
        if(k>arr[mid])
            start = mid+1;
        else
            End = mid-1;
        mid = (start+End)/2;
    }
    if(arr[mid]==k)
        return mid;
    else
        return -1;
}
