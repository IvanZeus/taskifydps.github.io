#ifndef SEARCH_H_INCLUDED
#define SEARCH_H_INCLUDED

int linear_search(int*, int, int);
void binary_search();

#endif // SEARCH_H_INCLUDED
